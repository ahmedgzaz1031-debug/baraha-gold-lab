// إعداد اتصال معمل براءة.
// تلقائي: إذا كان الملف _worker.js مرفوعاً مع الموقع يمرّر الموقع الاتصال بقاعدة البيانات عبر نفسه (يعمل بلا VPN).
// يدوي (اختياري): window.BARAHA_API='https://اسم.workers.dev';
(function(){try{
 if(window.BARAHA_API||!/^https?:$/.test(location.protocol))return;
 var k='barahaProxy_v1',now=Date.now(),c=null;
 try{c=JSON.parse(localStorage.getItem(k)||'null')}catch(e){}
 if(c&&now-c.t<(c.ok?864e5:3e5)){if(c.ok)window.BARAHA_API=location.origin+'/sb';return}
 var x=new XMLHttpRequest();x.open('GET','/sb/auth/v1/health',false);x.send();
 var ok=/json/i.test(x.getResponseHeader('content-type')||'')&&x.status!==404;
 try{localStorage.setItem(k,JSON.stringify({ok:ok,t:now}))}catch(e){}
 if(ok)window.BARAHA_API=location.origin+'/sb';
}catch(e){}})();
