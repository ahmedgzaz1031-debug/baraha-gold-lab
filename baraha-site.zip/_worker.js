// معمل براءة — وسيط على نفس الموقع: /sb/* يُمرَّر إلى Supabase من خوادم Cloudflare
// فيعمل الموقع وصفحة النتيجة عند من لا يصله supabase.co مباشرة (بدون VPN).
const TARGET='https://zzperikerogobbrnrnvn.supabase.co';
export default{
 async fetch(request,env){
  const u=new URL(request.url);
  if(u.pathname==='/sb'||u.pathname.startsWith('/sb/')){
   const t=new URL(TARGET+u.pathname.slice(3)+u.search);
   return fetch(new Request(t,request));
  }
  return env.ASSETS.fetch(request);
 }
};
