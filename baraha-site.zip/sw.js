/* Service Worker — معمل براءة
   «اعرض المخزَّن فوراً ثم حدّث في الخلفية»: الصفحة تفتح لحظياً، وإذا نزل تحديث جديد تظهر رسالة لإعادة التحميل.
   لا يخزّن طلبات قاعدة البيانات (Supabase) إطلاقاً. */
const CACHE='baraha-v20261108c';
const CORE=['./','./index.html','./manifest.webmanifest','./icon-64.png','./icon-192.png','./icon-512.png','./logo-brand.webp','./logo-receipt.png','./config.js'];
const LIB='cdn.jsdelivr.net';
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).catch(()=>{}));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(n=>n!==CACHE).map(n=>caches.delete(n)))).then(()=>self.clients.claim()));});
const sig=r=>r&&(r.headers.get('etag')||r.headers.get('last-modified')||r.headers.get('content-length')||'');
self.addEventListener('fetch',e=>{
  const r=e.request,u=new URL(r.url);
  if(r.method!=='GET')return;
  if(u.pathname.startsWith('/sb/'))return; // وسيط قاعدة البيانات: لا يُخزَّن أبداً
  const own=u.origin===location.origin,lib=u.hostname===LIB;
  if(!own&&!lib)return;
  e.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    const hit=await cache.match(r,{ignoreSearch:false});
    const net=fetch(r).then(async res=>{
      if(res&&(res.ok||res.type==='opaque')){
        if(own&&hit&&sig(hit)!==sig(res)&&(u.pathname.endsWith('/')||u.pathname.endsWith('index.html'))){
          (await self.clients.matchAll()).forEach(c=>c.postMessage('baraha-updated'));
        }
        cache.put(r,res.clone());
      }
      return res;
    }).catch(()=>null);
    if(hit){e.waitUntil(net);return hit;}
    const res=await net;
    return res||(await cache.match('./index.html'))||Response.error();
  })());
});
